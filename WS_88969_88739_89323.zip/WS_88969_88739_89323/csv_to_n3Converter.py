import csv
import sys

# Constantes dos prefixos dos irl's
movies_uri = "http://movies.ws/en/movie/"
pred_uri = "http://movies.ws/pred/"
diretor_uri = "http://movies.ws/en/director/"
country_uri = "http://movies.ws/en/country/"
language_uri = "http://movies.ws/en/language/"
genre_uri = "http://movies.ws/en/genre/"
plataforma_uri = "http://movies.ws/en/platform/"
comment_uri = "http://movies.ws/en/comment/"

xsd_prefix = "http://www.w3.org/2001/XMLSchema#"

# Escrever os prefixos no ficheiro
def write_prefix(rdf_file):
    rdf_file.write("@prefix xsd: <" + xsd_prefix + "> .\n")
    rdf_file.write("@prefix movie: <" + movies_uri + "> .\n")
    rdf_file.write("@prefix pred: <" + pred_uri + "> .\n")
    rdf_file.write("@prefix dir: <" + diretor_uri + "> .\n")
    rdf_file.write("@prefix country: <" + country_uri + "> .\n")
    rdf_file.write("@prefix lang: <" + language_uri + "> .\n")
    rdf_file.write("@prefix genre: <" + genre_uri + "> .\n")
    rdf_file.write("@prefix plat: <" + plataforma_uri + "> .\n")
    rdf_file.write("@prefix comm: <" + comment_uri + "> .\n")
    rdf_file.write("\n");

# Adiciona os nomes das plataformas de streaming ao ficheiro
def add_platform_ids(rdf_file):
    rdf_file.write("plat:netflix pred:name \"Netflix\"^^xsd:string .\n")
    rdf_file.write("plat:hulu pred:name \"Hulu\"^^xsd:string .\n")
    rdf_file.write("plat:prime_video pred:name \"Prime Video\"^^xsd:string .\n")
    rdf_file.write("plat:disney pred:name \"Disney+\"^^xsd:string .\n")

# Converte uma linha do csv (referente a um filme) para os triplos do ficheiro em N3
def process_csv_row(row, rdf_file, director_dict, genre_dict, country_dict, language_dict, platform_dict):
    #1. Verificar se os diretores já existem ou se é necessário criar os seus id e atributo nome
    directors = row[12]
    directors = list(set(directors.split(",")))
    
    for director in directors:
        d = director.strip()
        if(d not in director_dict.keys()):
            dir_id = d.lower().replace(" ", "_").replace("'", "_").replace(".", "_")
            rdf_file.write("dir:" + dir_id + " pred:name \"" + d + "\"^^xsd:string .\n")
            director_dict[d] = dir_id
            

    #2. Verificar se os géneros já existem ou se é necessário criar os seus id e nome
    genres = row[13]
    genres = list(set(genres.split(",")))

    for genre in genres:
        g = genre.strip()
        if(g not in genre_dict.keys()):
            gen_id = g.lower().replace(" ", "_").replace("-", "_")
            rdf_file.write("genre:" + gen_id + " pred:name \"" + g + "\"^^xsd:string .\n")
            genre_dict[g] = gen_id

    #3. Verificar se os países já existem ou se é necessário criar os seus id e nome 
    countries = row[14]
    countries = list(set(countries.split(",")))

    for country in countries:
        c = country.strip()
        if(c not in country_dict.keys()):
            country_id = c.lower().replace(" ", "_").replace("(", "").replace(")", "").replace("'", "_")
            rdf_file.write("country:" + country_id + " pred:name \"" + c + "\"^^xsd:string .\n")
            country_dict[c] = country_id

    #4. Verificar se as linguas já existem ou se é necessário criar os seus id e nome
    languages = row[15]
    languages = list(set(languages.split(",")))

    for language in languages:
        l = language.strip()
        if(l not in language_dict.keys()):
            lang_id = l.lower().replace(" ", "_").replace("(", "").replace(")", "")
            rdf_file.write("lang:" + lang_id + " pred:name \"" + l + "\"^^xsd:string .\n")
            language_dict[l] = lang_id

    #5. Criar os triplos do filme
    movie_id = "movie"+row[1]
    movie_title = row[2]
    movie_year = row[3]
    movie_age = row[4]
    movie_imdb = row[5]
    movie_netflix = row[7]
    movie_hulu = row[8]
    movie_prime = row[9]
    movie_disney = row[10]
    movie_runtime = row[16]

    rdf_file.write("movie:" + movie_id + " pred:name \"" + movie_title.replace("\"", "'") + "\"^^xsd:string;\n")

    # Escrever os realizadores do filme
    if(directors[0]!=""):
        rdf_file.write("\tpred:directed_by ")
        for director in directors:
            d = director.strip()
            rdf_file.write("dir:" + director_dict[d])
            if(d == directors[len(directors)-1].strip()):
                rdf_file.write(";\n")
            else:
                rdf_file.write(",\n\t\t")

    # Escrever a pontuação do IMDb do filme
    if(movie_imdb!=""):
        rdf_file.write("\tpred:scored \"" + movie_imdb + "\"^^xsd:float;\n")

    # Escrever o rating de idade do filme
    if(movie_age!=""):
        rdf_file.write("\tpred:age \"" + movie_age + "\"^^xsd:string;\n")

    # Escrever o runtime do filme
    if(movie_runtime!=""):
        rdf_file.write("\tpred:runtime \"" + movie_runtime + "\"^^xsd:int;\n")

    # Escrever os países do filme
    if(countries[0]!=""):
        rdf_file.write("\tpred:country ")
        for country in countries:
            c = country.strip()
            rdf_file.write("country:" + country_dict[c])
            if(c == countries[len(countries)-1].strip()):
                rdf_file.write(";\n")
            else:
                rdf_file.write(",\n\t\t")

    # Escrever as linguas do filme
    if(languages[0]!=""):
        rdf_file.write("\tpred:language ")
        for language in languages:
            l = language.strip()
            rdf_file.write("lang:" + language_dict[l])
            if(l == languages[len(languages)-1].strip()):
                rdf_file.write(";\n")
            else:
                rdf_file.write(",\n\t\t")

    # Escrever os géneros do filme
    if(genres[0]!=""):
        rdf_file.write("\tpred:genre ")
        for genre in genres:
            g = genre.strip()
            rdf_file.write("genre:" + genre_dict[g])
            if(g == genres[len(genres)-1].strip()):
                rdf_file.write(";\n")
            else:
                rdf_file.write(",\n\t\t")

    # Escrever os triplos das plataformas em que os filmes estão disponívies
    if(movie_netflix == "1" or movie_hulu == "1" or movie_prime == "1" or movie_disney == "1"):
        count = 0
        rdf_file.write("\tpred:available ")
        if(movie_netflix == "1"):
            count+=1
            rdf_file.write("plat:netflix")
        if(movie_hulu == "1"):
            if(count!=0):
                rdf_file.write(",\n\t\t")
            count+=1
            rdf_file.write("plat:hulu")
        if(movie_prime == "1"):
            if(count!=0):
                rdf_file.write(",\n\t\t")
            count+=1
            rdf_file.write("plat:prime_video")
        if(movie_disney == "1"):
            if(count!=0):
                rdf_file.write(",\n\t\t")
            count+=1
            rdf_file.write("plat:disney")
        rdf_file.write(";\n")
    
    rdf_file.write("\tpred:year \"" + movie_year + "\"^^xsd:string .\n")
    


# Main do programa
def main():

    if(len(sys.argv) != 3):
        print("Missing arguments!")
        print("Usage: python " + sys.argv[0] + " <csv_file:str> <rdf_n3_file:str>")
        exit(1)

    csv_file_name = sys.argv[1]
    rdf_file_name = sys.argv[2]

    csv_file = open(csv_file_name, mode="r", newline='')
    reader = csv.reader(csv_file)

    rdf_file = open(rdf_file_name, mode="w")

    write_prefix(rdf_file)
    add_platform_ids(rdf_file)
    rdf_file.write("\n")

    director_dict = dict()
    genre_dict = dict()
    country_dict = dict()
    language_dict = dict()
    platform_dict = dict()

    i = 0
    # Iterar sobre as linhas do ficheiro CSV
    for row in reader:
        if(i==0):
            i+=1
            continue
        process_csv_row(row, rdf_file, director_dict, genre_dict, country_dict, language_dict, platform_dict)
        rdf_file.write("\n");
    
    rdf_file.close()


if __name__ == "__main__":
    main()