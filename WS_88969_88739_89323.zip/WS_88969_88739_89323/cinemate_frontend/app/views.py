import time

from django.http import HttpRequest, HttpResponseRedirect
from django.shortcuts import render
from django.views.decorators.cache import cache_page
from django.views.decorators.csrf import csrf_protect

from .database.queries import *
from .database.wikidata_queries import *


# Create your views here.
def indexView(request):
    start = time.time()
    print("## INDEX: Start")
    assert isinstance(request, HttpRequest)

    #results_best_movie_list = []
    results_best_movie_list = get_filtered_movies(order_score_desc=True, limit=9)
    query_end = time.time()
    print("## INDEX: Best movie query took ", (query_end - start), " seconds")


    print("## INDEX: Start conditional rendering")
    render_start = time.time()

    if len(results_best_movie_list) == 0:
        render_end = time.time()
        print("## INDEX: Render return error (took ", (render_end - render_start), " seconds")
        return render(request,
                      "index.html",
                      {"error": True})
    else:
        render_end = time.time()
        print("## INDEX: Render return best movies (took ", (render_end - render_start)," seconds")
        return render(
            request,
            "index.html",
            {
                "results_best_movie_list": results_best_movie_list,
                "error": False
            })



@cache_page(60 * 15)
@csrf_protect
def resultsView(request):
    start = time.time()
    print("### RESULTS VIEW: Start")
    print("### RESULTS VIEW: Fetching Genres...")
    genres_list = get_all_genres()
    genres_end = time.time()
    print("### RESULTS VIEW: Got genres. Took ", (genres_end-start), " seconds")

    error = False
    if len(genres_list) == 0:
        error = True

    movies_results = []

    assert isinstance(request, HttpRequest)

    function_start = time.time()

    if request.method == "POST":
        search_start = time.time()
        if "min_score" in request.POST and "max_score" in request.POST and "filter_year" in request.POST:
            print("### RESULTS VIEW | Got a filtering request")

            min_score = request.POST["min_score"]
            max_score = request.POST["max_score"]
            year = request.POST["filter_year"]

            print("### RESULTS VIEW | Filtering parameters")
            print("- min_score: ", min_score)
            print("- max_score: ", max_score)
            if year:
                print("- year: ", year)

            # get genres that were selected in filtering page
            checked_genres = []
            print("### RESULTS VIEW | Checking selected genres")
            for genre in genres_list:
                if genre in request.POST:
                    checked_genres.append(genre)

            genre_check_end = time.time()
            print("### RESULTS VIEW | Checked selected genres. Took ", (genre_check_end - search_start), " seconds.")
            print("### RESULTS VIEW | Found ", len(checked_genres), " genres.")

            print("### RESULTS VIEW | Starting filtering query...")
            query_start = time.time()

            # query movies for all filtering parameters
            if len(checked_genres) != 0:
                if year and year.isnumeric():
                    movies_results = get_filtered_movies(genres=checked_genres, score_lower=min_score, score_upper=max_score, year=year)
                    query_end = time.time()
                    print("### RESULTS VIEW | Got filtering results (", len(movies_results), "). Took ", (query_end-query_start), " seconds.")
                else:
                    movies_results = get_filtered_movies(genres=checked_genres, score_lower=min_score, score_upper=max_score)
                    query_end = time.time()
                    print("### RESULTS VIEW | Got filtering results (", len(movies_results), "). Took ", (query_end - query_start), " seconds.")
            # query without genres
            else:
                if year and year.isnumeric():
                    # query movies for all filtering parameters, except genres (in case none was selected)
                    movies_results = get_filtered_movies(score_lower=min_score, score_upper=max_score, year=year)
                    query_end = time.time()
                    print("### RESULTS VIEW | Got filtering results (", len(movies_results), "). Took ", (query_end - query_start), " seconds.")
                else:
                    # query movies only for score range (if no genres and year was provided)
                    movies_results = get_filtered_movies(score_lower=min_score, score_upper=max_score)
                    query_end = time.time()
                    print("### RESULTS VIEW | Got filtering results (", len(movies_results), "). Took ", (query_end - query_start), " seconds.")


            #print("### resultsView | Filtering results\n", movies_results)

            print("### RESULTS VIEW | Render start")
            render_start = time.time()

            if min_score and max_score: # and year
                render_end = time.time()
                print("### RESULTS VIEW | Render results with score and year. Took ", (render_end-render_start), " seconds.")
                return render(
                    request,
                    "results.html",
                    {
                        "results_movie_list": movies_results,
                        "genres_list": genres_list,
                        "error": error
                    })
            else:
                render_end = time.time()
                print("### RESULTS VIEW | Render error. Took ", (render_end - render_start), " seconds.")
                return render(request,
                              "index.html",
                              {"error": True})
        elif "query_string" in request.POST and "query_entity" in request.POST:
            print("### RESULTS VIEW | Got a search request")
            query_string = request.POST["query_string"]
            query_entity = request.POST["query_entity"]

            print("### RESULTS VIEW | Search parameters")
            print("- search text: ", query_string)
            print("- search criteria: ", query_entity)

            print("### RESULTS VIEW | Starting search query...")
            query_start = time.time()

            if query_entity == "movie":
                movies_results = get_filtered_movies(movie_name_regex=query_string)
                query_end = time.time()
                print("### RESULTS VIEW | Got search results. Took ", (query_end - query_start), " seconds.")
            elif query_entity == "director":
                movies_results = get_filtered_movies(dir_name=query_string)
                query_end = time.time()
                print("### RESULTS VIEW | Got search results. Took ", (query_end - query_start), " seconds.")
            elif query_entity == "country":
                movies_results = get_filtered_movies(country=query_string)
                query_end = time.time()
                print("### RESULTS VIEW | Got search results. Took ", (query_end - query_start), " seconds.")
            elif query_entity == "language":
                movies_results = get_filtered_movies(language=query_string)
                query_end = time.time()
                print("### RESULTS VIEW | Got search results. Took ", (query_end - query_start), " seconds.")

            error_genres = False
            error_movies_results = False

            if len(genres_list) == 0:
                error_genres = True

            if len(movies_results) == 0:
                error_movies_results = True

            print("### RESULTS VIEW | Search results -> ", movies_results)

            render_start = time.time()
            if query_string and query_entity:
                render_end = time.time()
                print("### RESULTS VIEW | Render search results. Took ", (render_end - render_start), " seconds.")
                return render(
                    request,
                    "results.html",
                    {
                        "results_movie_list": movies_results,
                        "genres_list": genres_list,
                        "error_genres": error_genres,
                        "error_movies_results": error_movies_results,
                    })
            else:
                render_end = time.time()
                print("### RESULTS VIEW | Render search results. Took ", (render_end - render_start), " seconds.")
                return render(request,
                              "index.html",
                              {"error": True})
        else:
            return render(request,
                          "index.html",
                          {"error": True})
    else:
        function_end = time.time()
        print("### RESULTS VIEW | Render with no data. Took ", (function_end - function_start), " seconds.")
        no_search = True
        tparams = {
            "genres_list": genres_list,
            "no_search": no_search,
            "error_genres": False,
            "error_movies_results": False,
        }
        return render(request, 'results.html', tparams)


@cache_page(60 * 15)
@csrf_protect
def movieDetailsView(request, movie_name):
    start = time.time()
    print("### MOVIE DETAILS VIEW: Start")
    assert isinstance(request, HttpRequest)

    if "author" in request.POST and "content" in request.POST:
        print("### MOVIE DETAILS VIEW | Got a request to add comment")
        author = request.POST["author"]
        content = request.POST["content"]

        print("### MOVIE DETAILS VIEW | New comment parameters")
        print("- author: ", author)
        print("- content: ", content)

        comment_start = time.time()
        if author and content:
            add_comment(movie_name,author, content)
            comment_end = time.time()
            print("### MOVIE DETAILS VIEW | Commented added. Took ", (comment_end-comment_start), " seconds.")
    if "comment_id" in request.POST:
        print("### MOVIE DETAILS VIEW | Got a request to remove comment")
        comment_id = request.POST["comment_id"]

        print("### MOVIE DETAILS VIEW | Remove comment parameters")
        print("- comment id: ", comment_id)

        comment_start = time.time()
        if comment_id:
            remove_comment(comment_id)
            comment_end = time.time()
            print("### MOVIE DETAILS VIEW | Commented removed. Took ", (comment_end - comment_start), " seconds.")

    movie_start = time.time()
    movie = get_movie_info(movie_name)[0]
    movie_end = time.time()
    print("### MOVIE DETAILS VIEW | Got movie from GraphDB. Took ", (movie_end - movie_start), " seconds.")

    wiki_movie_start = time.time()
    movie_wikidata = getWikidataMovieInfo(movie_name)
    wiki_movie_end = time.time()
    print("### MOVIE DETAILS VIEW | Got extra info from Wikidata. Took ", (wiki_movie_end - wiki_movie_start), " seconds.")
    print("### MOVIE DETAILS VIEW | Wiki data info -> ", movie_wikidata)

    movie["wikidata"] = movie_wikidata

    print("### MOVIE DETAILS VIEW | Final movie -> ", movie)

    num_comments = len(movie["comments"])
    cast = []
    if "cast" in movie_wikidata.keys():
        cast = movie_wikidata["cast"]

    tparams = {
        'movie': movie,
        'cast': cast,
        'num_comments': num_comments
    }
    return render(request, 'movie_details.html', tparams)

def directorDetailsView(request, director_code):
    assert isinstance(request, HttpRequest)
    get_actor_start = time.time()
    # actor = get_actor_info()
    print("### DIRECTOR DETAILS VIEW | Requesting director...")
    # actor_id = "http://www.wikidata.org/entity/Q38111" # default
    director = getWikidataDirectorInfo(director_code)
    get_actor_end = time.time()
    print("### DIRECTOR DETAILS VIEW | Got director . Took", (get_actor_end - get_actor_start), " seconds.")
    print("director -> ", director)

    if len(director) == 0:
        # return to previous page
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

    num_awards_recv = 0
    if "awards_rcv" in director.keys():
        num_awards_recv = len(director["awards_rcv"])

    num_nominated_awards = 0
    if "awards_nominated" in director.keys():
        num_nominated_awards = len(director["awards_nominated"])

    num_occupations = 0
    if "occupations" in director.keys():
        num_occupations = len(director["occupations"])

    tparams = {
        "director": director,
        "num_awards_recv": num_awards_recv,
        "num_nominated_awards": num_nominated_awards,
        "num_occupations": num_occupations
    }
    return render(request, 'director_details.html', tparams)

def movieMapsView(request):
    tparams = {
        'Title':'Hi',
    }
    return render(request, 'movie_maps.html', tparams)

def suggestionView(request):
    assert isinstance(request, HttpRequest)
    print("aaaaaaa")
    tparams = {
        'empty': False,
    }
    if request.method == "POST":
        print("post")
        if "movie_name" in request.POST and "release_year" in request.POST:
            print("### MOVIE DETAILS VIEW | Got a request to add comment")
            movie_name = request.POST["movie_name"]
            release_year = request.POST["release_year"]

            print("### ADD SUGGESTION VIEW | New suggestion parameters")
            print("- movie_name: ", movie_name)
            print("- release_year: ", release_year)

            if movie_name and release_year:
                add_suggestion(movie_name, release_year)
                print("suggestion added")
                tparams = {
                    'success': True,
                    'empty' : False,
                }
                return render(request, 'suggestion.html', tparams)
            else:
                tparams = {
                    'empty': True,
                }
                return render(request, 'suggestion.html', tparams)

    return render(request, 'suggestion.html', tparams)

def suggestionsListView(request):
    suggestions_list = get_suggestions()
    for s in suggestions_list:
        print("suggestion ", s)
    error_empty = False

    if (len(suggestions_list) > 0):
        error_empty = False
        tparams = {
            'suggestions_list': suggestions_list,
            'error_empty': error_empty,
        }
    else:
        error_empty = True
        tparams = {
            'error_empty': True,
        }

    if request.method == 'POST':
        if "suggestion_id" in request.POST:
            suggestion_id = request.POST["suggestion_id"]

            if suggestion_id:
                remove_suggestion(suggestion_id)
                suggestions_list = get_suggestions()
                if (len(suggestions_list) > 0):
                    error_empty = False
                    tparams = {
                        'suggestions_list': suggestions_list,
                        'error_empty': error_empty,
                    }
                else:
                    error_empty = True
                    tparams = {
                        'error_empty': True,
                    }
                return render(request, 'suggestions_list.html', tparams)

    return render(request, 'suggestions_list.html', tparams)

def actorDetailsView(request, actor_code): #actor name
    assert isinstance(request, HttpRequest)
    get_actor_start = time.time()
    #actor = get_actor_info()
    print("### ACTOR DETAILS VIEW | Requesting actor...")
    #actor_id = "http://www.wikidata.org/entity/Q38111" # default
    actor = getWikidataActorInfo(actor_code)
    get_actor_end = time.time()
    print("### ACTOR DETAILS VIEW | Got actor . Took", (get_actor_end - get_actor_start), " seconds.")
    print("actor -> ", actor)



    if len(actor) == 0:
        # return to previous page
        return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))

    # remove time information from date
    if "work_period_start" in actor.keys():
        actor["work_period_start"] = actor["work_period_start"].split("T")[0]

    num_awards_recv = 0
    if "awards_rcv" in actor.keys():
        num_awards_recv = len(actor["awards_rcv"])

    num_nominated_awards = 0
    if "awards_nominated" in actor.keys():
        num_nominated_awards = len(actor["awards_nominated"])

    num_occupations = 0
    if "occupations" in actor.keys():
        num_occupations = len(actor["occupations"])



    tparams = {
        "actor": actor,
        "num_awards_recv": num_awards_recv,
        "num_nominated_awards": num_nominated_awards,
        "num_occupations" : num_occupations
    }
    return render(request, 'actor_details.html', tparams)

def addMovieView(request):
    genres_list = get_all_genres()
    platforms_list = ["Netflix","Hulu","PrimeVideo","Disney"]
    countries_list = get_all_countries()
    languages_list = get_all_languages()
    #error = False
    #TODO: verificar se as listas estão vazias

    if request.method == "POST":
        if "movie_title" in request.POST and "director" in request.POST and "runtime" in request.POST and "age" in request.POST and "releaseYear" in request.POST and "score" in request.POST:
            name = request.POST["movie_title"]
            director = request.POST["director"]
            runtime = request.POST["runtime"]
            age = request.POST["age"]
            releaseYear = request.POST["releaseYear"]
            score = request.POST["score"]

            # get genres that were selected
            checked_genres = []
            for genre in genres_list:
                if genre in request.POST:
                    checked_genres.append(genre)

            # get platforms that were selected
            checked_plat = []
            for plat in platforms_list:
                if plat in request.POST:
                    checked_plat.append(plat)

            # get countries that were selected
            checked_countries = []
            for country in countries_list:
                if country in request.POST:
                    checked_countries.append(country)

            # get countries that were selected
            checked_lang = []
            for lang in languages_list:
                if lang in request.POST:
                    checked_lang.append(lang)

            if name and director and runtime and age and releaseYear and score and checked_genres and checked_plat and checked_countries and checked_lang:
                add_movie(name,director,checked_genres, checked_countries, checked_lang, age, runtime, score, releaseYear, checked_plat)
                print("New movie added")
                tparams = {
                    "genres_list": genres_list,
                    "platforms_list": platforms_list,
                    "countries_list": countries_list,
                    "languages_list": languages_list,
                    "success":True,
                }
                return render(request, 'add_movie.html', tparams)

            else:
                tparams = {
                    "genres_list": genres_list,
                    "platforms_list": platforms_list,
                    "countries_list": countries_list,
                    "languages_list": languages_list,
                    "empty":True,
                }

    else:
        tparams = {
            "genres_list": genres_list,
            "platforms_list":platforms_list,
            "countries_list":countries_list,
            "languages_list":languages_list,
        }

    return render(request, 'add_movie.html', tparams)

def inferenceView(request):
    start = time.time()
    print("### INFERENCE VIEW: Start")
    assert isinstance(request, HttpRequest)

    if "runtime" in request.POST:
        infer_start = time.time()
        print("### INFERENCE VIEW: Inferring movies runtime...")

        infer_long_length_movies()
        infer_average_length_movies()
        infer_short_length_movies()
        infer_bad_movies()

        infer_end = time.time()
        print("### INFERENCE VIEW | Movies runtime inferred. Took ", (infer_end - infer_start), " seconds.")

        tparams = {
            "runtime_inferred" : True
        }

        return render(request, 'inference.html', tparams)
    elif "age" in request.POST:
        infer_start = time.time()
        print("### INFERENCE VIEW: Inferring public age...")

        infer_children_movies()
        infer_young_adult_movies()
        infer_adults_movies()
        infer_everyone_movies()

        infer_end = time.time()
        print("### INFERENCE VIEW | Public age inferred. Took ", (infer_end - infer_start), " seconds.")

        tparams = {
            "age_inferred": True
        }

        return render(request, 'inference.html', tparams)
    elif "quality" in request.POST:
        infer_start = time.time()
        print("### INFERENCE VIEW: Inferring movies quality...")

        infer_amazing_movies()
        infer_good_movies()
        infer_avg_movies()
        infer_bad_movies()

        infer_end = time.time()
        print("### INFERENCE VIEW | Movies quality inferred. Took ", (infer_end - infer_start), " seconds.")

        tparams = {
            "quality_inferred": True
        }

        return render(request, 'inference.html', tparams)

    else:
        end = time.time()
        print("### INFERENCE VIEW: Rendered without inferences in ", (end - start), " seconds.")
        tparams = {
            "runtime_inferred": False,
            "age_inferred": False,
            "quality_inferred": False
        }

        return render(request, 'inference.html', tparams)