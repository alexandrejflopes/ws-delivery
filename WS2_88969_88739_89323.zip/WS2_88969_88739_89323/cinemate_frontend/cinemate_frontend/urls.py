"""cinemate_frontend URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from app import views
from django.conf.urls import url
from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('', views.indexView, name='index-view'),
    path('results/', views.resultsView, name='results-view'),
    url(r'^director_details/(?P<director_code>[\w\'-.:?,!;\[\]%&=$@*+#_\\/–… ]+)/$', views.directorDetailsView, name='director_details'),
    url(r'^actor_details/(?P<actor_code>[\w\'-.:?,!;\[\]%&=$@*+#_\\/–… ]+)/$', views.actorDetailsView, name='actor_details'),
    path('movie_maps', views.movieMapsView, name='movie_maps-view'),
    path('suggestion', views.suggestionView, name='suggestion-view'),
    path('suggestions_list', views.suggestionsListView, name='suggestions_list-view'),
    path('add_movie', views.addMovieView, name='add_movie-view'),
    path('inference', views.inferenceView, name='inference'),
    #url(r'^results/(?P<search_string>[\w\-]+)/(?P<search_criteria>[\w\-]+)/$', views.resultsView, name='results-view'),
    #path('movie_details', views.movieDetailsView, name='movie_details-view'),
    url(r'^movie_details/(?P<movie_name>[\w\'-.:?,!;\[\]%&=$@*+#_\\/–… ]+)/$', views.movieDetailsView, name='movie_details'),
]
