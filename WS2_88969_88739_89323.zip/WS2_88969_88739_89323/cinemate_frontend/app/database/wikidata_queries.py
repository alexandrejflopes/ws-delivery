from SPARQLWrapper import SPARQLWrapper2

def getWikidataMovieInfo(movie_name):
    sparql = SPARQLWrapper2("https://query.wikidata.org/sparql")
    sparql.setQuery("""SELECT DISTINCT ?item ?itemLabel ?titulo ?logo ?logoLabel ?director ?directorLabel ?cast ?castLabel ?screenwriter ?screenwriterLabel ?awardsRcv ?awardsRcvLabel
    WHERE {{
        ?item wdt:P31 wd:Q11424.
        ?item wdt:P1476 ?titulo.
        FILTER(regex(?titulo, "{}", "i"))
        ?item wdt:P154 ?logo.
        ?item wdt:P57 ?director.
        ?item wdt:P161 ?cast.
        ?item wdt:P58 ?screenwriter.
        Optional{{?item wdt:P166 ?awardsRcv .}}
        SERVICE wikibase:label {{ bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }}
        }}
    """.format(movie_name))
    director_set = set()
    directors = []
    cast_set = set()
    cast = []
    awards = set()
    doc = {}
    for result in sparql.query().bindings:
        if result["cast"].value not in cast_set:
            cast_set.add(result["cast"].value)
            cast_split = result["cast"].value.split("/")
            cast.append({"cast_code": cast_split[len(cast_split)-1], "cast_label": result["castLabel"].value})
        if result.get("awardsRcvLabel", 0) != 0:
            awards.add(result.get("awardsRcvLabel").value)
        if result["director"].value not in director_set:
            director_set.add(result["director"].value)
            director_split = result["director"].value.split("/")
            directors.append({"director_code": director_split[len(director_split)-1], "director_label": result["directorLabel"].value})
        doc["name"] = result["titulo"].value
        doc["logo"] = result["logoLabel"].value
        doc["screenwriter"] = result["screenwriterLabel"].value
    if doc.get("name", 0) != 0:
        doc["cast"] = cast
        doc["awards"] = list(awards)
        doc["directors"] = directors
    return doc

def getWikidataActorInfo(actorCode):
    #url_list = actorId.split("/")
    #true_id = url_list[len(url_list)-1]
    sparql = SPARQLWrapper2("https://query.wikidata.org/sparql")
    sparql.setQuery("""SELECT ?fullName ?awardsRcvLabel ?awardsNominatedLabel ?photoLabel ?birth_date ?birth_placeLabel ?genderLabel ?wordPeriod ?educationLabel ?residenceLabel ?occupationLabel ?followers
    WHERE {{
        wd:{} wdt:P1477 ?fullName;
            wdt:P569 ?birth_date;
            wdt:P19 ?birth_place;
            wdt:P21 ?gender.
        optional{{
            wd:{} wdt:P166 ?awardsRcv;
                    wdt:P1411 ?awardsNominated;
                    wdt:P18 ?photo;
                    wdt:P2031 ?wordPeriod;
                    wdt:P69 ?education;
                    wdt:P551 ?residence;
                    wdt:P106 ?occupation;
                    wdt:P8687 ?followers.
        }}
        SERVICE wikibase:label {{ bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }}
    }}
    """.format(actorCode, actorCode))

    awards_rvc = set()
    awards_nominated = set()
    occupations = set()
    doc = {}
    doc["id"] = actorCode

    for result in sparql.query().bindings:
        doc["name"] = result["fullName"].value
        doc["birth_date"] = result["birth_date"].value.split("T")[0]
        doc["birth_place"] = result["birth_placeLabel"].value
        doc["gender"] = result["genderLabel"].value
        if result.get("awardsRcvLabel", 0) != 0:
            awards_rvc.add(result.get("awardsRcvLabel").value)
        if result.get("awardsNominatedLabel", 0) != 0:
            awards_nominated.add(result["awardsNominatedLabel"].value)
        if result.get("occupationLabel", 0) != 0:
            occupations.add(result["occupationLabel"].value)
        if result.get("wordPeriod", 0) != 0:
            doc["work_period_start"] = result["wordPeriod"].value.split("T")[0]
        if result.get("educationLabel", 0) != 0:
            doc["education"] = result["educationLabel"].value
        if result.get("residenceLabel", 0) != 0:
            doc["residence"] = result["residenceLabel"].value
        if result.get("followers", 0) != 0:
            doc["followers"] = result["followers"].value
        if result.get("photoLabel", 0) != 0:
            doc["photo"] = result["photoLabel"].value

    if doc.get("name", 0) != 0:
        doc["awards_rcv"] = list(awards_rvc)
        doc["awards_nominated"] = list(awards_nominated)
        doc["occupations"] = list(occupations)
    return doc

def getWikidataDirectorInfo(directorCode):
    #url_list = directorId.split("/")
    #true_id = url_list[len(url_list)-1]
    sparql = SPARQLWrapper2("https://query.wikidata.org/sparql")
    sparql.setQuery("""SELECT ?fullName ?awardsRcvLabel ?awardsNominatedLabel ?photoLabel ?birth_date ?birth_placeLabel ?genderLabel ?wordPeriod ?educationLabel ?residenceLabel ?occupationLabel ?followers
    WHERE {{
        wd:{} wdt:P1477 ?fullName;
            wdt:P569 ?birth_date;
            wdt:P19 ?birth_place;
            wdt:P21 ?gender.
        optional{{
            wd:{} wdt:P166 ?awardsRcv;
                    wdt:P1411 ?awardsNominated;
                    wdt:P18 ?photo;
                    wdt:P69 ?education;
                    wdt:P106 ?occupation.
        }}
        SERVICE wikibase:label {{ bd:serviceParam wikibase:language "[AUTO_LANGUAGE],en". }}
    }}
    """.format(directorCode, directorCode))

    awards_rvc = set()
    awards_nominated = set()
    occupations = set()
    doc = {}
    doc["id"] = directorCode

    for result in sparql.query().bindings:
        doc["name"] = result["fullName"].value
        doc["birth_date"] = result["birth_date"].value.split("T")[0]
        doc["birth_place"] = result["birth_placeLabel"].value
        doc["gender"] = result["genderLabel"].value
        if result.get("awardsRcvLabel", 0) != 0:
            awards_rvc.add(result.get("awardsRcvLabel").value)
        if result.get("awardsNominatedLabel", 0) != 0:
            awards_nominated.add(result["awardsNominatedLabel"].value)
        if result.get("occupationLabel", 0) != 0:
            occupations.add(result["occupationLabel"].value)
        if result.get("educationLabel", 0) != 0:
            doc["education"] = result["educationLabel"].value
        if result.get("photoLabel", 0) != 0:
            doc["photo"] = result["photoLabel"].value

    if doc.get("name", 0) != 0:
        doc["awards_rcv"] = list(awards_rvc)
        doc["awards_nominated"] = list(awards_nominated)
        doc["occupations"] = list(occupations)
    return doc