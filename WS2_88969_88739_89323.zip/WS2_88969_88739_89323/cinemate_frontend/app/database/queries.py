import json

from s4api.graphdb_api import GraphDBApi
from s4api.swagger import ApiClient

endpoint = "http://localhost:7200"
repo_name = "cinemate"
client = ApiClient(endpoint=endpoint)
accessor = GraphDBApi(client)



def get_all_genres():
    genres = []

    query = """
    PREFIX pred:<http://movies.ws/pred/> 
    SELECT distinct ?name
    WHERE{
        ?filmID pred:genre ?genreId .
        ?genreId pred:name ?name .
    }
    """
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)

    for e in res['results']['bindings']:
        genres.append(e['name']['value'])

    return genres

def get_all_countries():
    countries = []

    query = """
    PREFIX pred:<http://movies.ws/pred/> 
    SELECT distinct ?name
    WHERE{
        ?filmID pred:country ?countryId .
        ?countryId pred:name ?name .
    }
    """
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)

    for e in res['results']['bindings']:
        countries.append(e['name']['value'])

    return countries

def get_all_languages():
    languages = []

    query = """
    PREFIX pred:<http://movies.ws/pred/> 
    SELECT distinct ?name
    WHERE{
        ?filmID pred:language ?langId .
        ?langId pred:name ?name .
    }
    """
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)

    for e in res['results']['bindings']:
        languages.append(e['name']['value'])

    return languages

def get_movie_info(accessor, repo_name, movie_name):
    return_dict = {}
    return_dict["name"] = movie_name
    # Get first atributes
    query = """
    PREFIX pred: <http://movies.ws/pred/>
    select * where {{ 
        ?movie pred:name "{}" .
        ?movie pred:year ?year .
        ?movie pred:scored ?score .
        optional {{
        ?movie pred:ranking ?ranking .
        ?movie pred:age_category ?age_category .
        ?movie pred:length ?length .
    }}
    }}
    """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)

    for e in res['results']['bindings']:
        if e.get('ranking', False):
            return_dict["ranking"] = e['ranking']['value']
        if e.get('age_category', False):
            return_dict["age_category"] = e['age_category']['value']
        if e.get('length', False):
            return_dict["length"] = e['length']['value']
        return_dict["movie_id"] = e['movie']['value']
        return_dict["score"] = e['score']['value']
        return_dict["year"] = e['year']['value']

    # Get directors
    query = """
        PREFIX pred: <http://movies.ws/pred/>
        select ?dir_name where {{ 
            ?movie pred:name "{}" .
            ?movie pred:directed_by ?dir .
            ?dir pred:name ?dir_name .
        }}
        """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    directors = []
    for e in res['results']['bindings']:
        directors.append(e['dir_name']['value'])
    return_dict["directors"] = directors

    # Get countries
    query = """
            PREFIX pred: <http://movies.ws/pred/>
            select ?country_name where {{ 
                ?movie pred:name "{}" .
                ?movie pred:country ?country .
                ?country pred:name ?country_name .
            }}
            """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    countries = []
    for e in res['results']['bindings']:
        countries.append(e['country_name']['value'])
    return_dict["countries"] = countries

    # Get languages
    query = """
            PREFIX pred: <http://movies.ws/pred/>
            select ?lang_name where {{ 
                ?movie pred:name "{}" .
                ?movie pred:language ?lang .
                ?lang pred:name ?lang_name .
            }}
            """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    languages = []
    for e in res['results']['bindings']:
        languages.append(e['lang_name']['value'])
    return_dict["languages"] = languages

    # Get genres
    query = """
            PREFIX pred: <http://movies.ws/pred/>
            select ?genre_name where {{ 
                ?movie pred:name "{}" .
                ?movie pred:genre ?genre .
                ?genre pred:name ?genre_name .
            }}
            """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    genres = []
    for e in res['results']['bindings']:
        genres.append(e['genre_name']['value'])
    return_dict["genres"] = genres

    # Get platforms
    query = """
            PREFIX pred: <http://movies.ws/pred/>
            select ?plat_name where {{ 
                ?movie pred:name "{}" .
                ?movie pred:available ?plat .
                ?plat pred:name ?plat_name .
            }}
            """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    platforms = []
    for e in res['results']['bindings']:
        platforms.append(e['plat_name']['value'])
    return_dict["platforms"] = platforms

    # Get comments
    query = """
            PREFIX pred: <http://movies.ws/pred/>
            select ?comment ?author ?content where {{ 
                ?movie pred:name "{}" .
                ?movie pred:comment ?comment .
                ?comment pred:author ?author .
                ?comment pred:content ?content .
            }}
            """.format(movie_name)

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    comments = []
    for e in res['results']['bindings']:
        comm = {"id": e['comment']['value'], "author": e['author']['value'], "content": e['content']['value']}
        comments.append(comm)
    return_dict["comments"] = comments

    return [return_dict]

def get_available_platforms(movie_name):
    return_dict = {}
    query = """
                PREFIX pred: <http://movies.ws/pred/>
                select ?plat_name where {{ 
                    ?movie pred:name "{}" .
                    ?movie pred:available ?plat .
                    ?plat pred:name ?plat_name .
                }}
                """.format(movie_name)
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    platforms = []
    for e in res['results']['bindings']:
        platforms.append(e['plat_name']['value'])
    return_dict["platforms"] = platforms

    return return_dict


def get_filtered_movies(movie_name_regex=None, dir_name=None, year=None, country=None, genres=None, language=None,
                        score_upper=None, score_lower=None, order_score_desc=False, limit=None):
    query = """PREFIX pred: <http://movies.ws/pred/>
    select distinct ?movie_name where { 
    ?movie pred:name ?movie_name .
    """
    if movie_name_regex:
        query = query + """filter regex(?movie_name, "{}", "i")
                """.format(movie_name_regex)
    if dir_name:
        query = query + """?movie pred:directed_by ?dir_id .
        ?dir_id pred:name ?dir_name .
        filter regex(?dir_name, "{}", "i")
        """.format(dir_name)
    if year:
        query = query + """?movie pred:year "{}" .
                """.format(year)
    if country:
        query = query + """?movie pred:country ?country .
        ?country pred:name ?country_name .
        filter regex(?country_name, "{}", "i")
        """.format(country)
    if genres:
        i = 0
        for genre in genres:
            query = query + """?movie pred:genre ?{genre_id} .
                    ?{genre_id} pred:name "{genre_name}" .
                    """.format(genre_id="genre"+str(i), genre_name=genre)
            i = i + 1
    if language:
        query = query + """?movie pred:language ?lang .
        ?lang pred:name ?lang_name .
        filter regex(?lang_name, "{}", "i")
        """.format(language)
    query = query + """?movie pred:scored ?score .
    """
    if score_upper and score_lower:
        query = query + """filter(?score > {})
        filter(?score < {})
        """.format(score_lower, score_upper)
    query = query + """}"""
    if order_score_desc:
        query = query + """ ORDER BY desc(?score)
        """
    if limit:
        query = query + """ LIMIT {}
        """.format(str(limit))

    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    names = []
    for e in res['results']['bindings']:
        names.append(e['movie_name']['value'])

    movies = []
    for n in names:
        movies.append(get_movie_info(n)[0])

    return movies

def add_comment(movie_name, author, content):
    prefix_comm = "http://movies.ws/en/comment/"
    query = '''PREFIX pred: <http://movies.ws/pred/>
    PREFIX comm: <http://movies.ws/en/comment/>
    select distinct ?comment where {{ 
    ?movie pred:comment ?comment .
    ?movie pred:name "{}"
    }} ORDER BY desc(?comment)'''.format(movie_name)
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    l = []
    for e in res['results']['bindings']:
        l.append(e['comment']['value'])


    if len(l) == 0:
        comm_id = "comment_0"
    else:
        new_l = [int(c.split("_")[len(c.split("_")) - 1]) for c in l]
        comm_id = "comment_" + str(max(new_l)+1)

    query = """PREFIX pred: <http://movies.ws/pred/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
    PREFIX comm: <http://movies.ws/en/comment/>
    insert {{
    ?movie pred:comment comm:{comm_id} .
    comm:{comm_id} pred:author "{author}"^^xsd:string .
    comm:{comm_id} pred:content "{content}"^^xsd:string .
    }}
    where {{ ?movie pred:name "{movie}"^^xsd:string .}}""".format(author=author, content=content, movie=movie_name, comm_id=comm_id)
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)


def remove_comment(comment_id):
    query = """PREFIX pred: <http://movies.ws/pred/>
    delete {{
    ?movie pred:comment <{comm_id}> .
    <{comm_id}> ?p ?o .
    }}
    where {{ 	<{comm_id}> ?p ?o .
    ?movie pred:comment <{comm_id}> .}}""".format(comm_id = comment_id)
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)


def get_suggestions():
    query = """
    PREFIX movc: <http://movies.ws/en/class/>
    PREFIX pred: <http://movies.ws/pred/>
    SELECT  ?entity ?name ?year
    WHERE{
        ?entity a movc:Suggestion .
        ?entity pred:name ?name .
        ?entity pred:year ?year .
    }
    """
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    l = []
    for e in res['results']['bindings']:
        l.append({"id": e['entity']['value'], "name": e['name']['value'], "year": e["year"]["value"]})
    return l

def add_suggestion(movie_name, release_year):
    query = """PREFIX movc: <http://movies.ws/en/class/>
            SELECT  ?entity
            WHERE{
                ?entity a movc:Suggestion
            }"""
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    l = []
    for e in res['results']['bindings']:
        l.append(e['entity']['value'])

    if len(l) == 0:
        suggestion_id = "suggestion_0"
    else:
        new_l = [int(c.split("_")[len(c.split("_")) - 1]) for c in l]
        suggestion_id = "suggestion_" + str(max(new_l) + 1)

    query = """PREFIX pred: <http://movies.ws/pred/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
    PREFIX sugg: <http://movies.ws/en/suggestion/>
    PREFIX comm: <http://movies.ws/en/comment/>
    PREFIX movc: <http://movies.ws/en/class/>
    insert data {{
        sugg:{id} a movc:Suggestion .
        sugg:{id} pred:year {year} .
        sugg:{id} pred:name "{title}"^^xsd:string .
    }}""".format(id=suggestion_id, year=release_year, title=movie_name)

    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)

def remove_suggestion(suggestion_id):
    query = """
        PREFIX pred: <http://movies.ws/pred/>
        DELETE {{ <{suggestion_id}> pred:name ?name .
            <{suggestion_id}> pred:year ?year .
        }}
        WHERE{{
            <{suggestion_id}> pred:name ?name .
            <{suggestion_id}> pred:year ?year .
        }}
    """.format(suggestion_id=suggestion_id)
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)


'''
name = "New mooovie"
director = "Christopher Nolan"
genres = ["Action", "Thriller"]
country = "Portugal"
language = "English"
age = "13+"
runtime = 130
score = 7.5
year = 2010
platforms = ["Netflix", "Hulu"]
'''
'''
name = "New countries and langs"
director = "new director"
genres = ["Action", "Thriller"]
country = ["Portugal", "Ireland"]
language = ["English", "German"]
age = "13+"
runtime = 130
score = 7.5
year = 2010
platforms = ["Netflix", "Hulu"]
'''
def add_movie(name, director, genres, countries, languages, age, runtime, score, year, platforms):
    # Generate new movie id
    query = """PREFIX movc: <http://movies.ws/en/class/>
            SELECT (count(distinct ?entity) AS ?Movies)
            WHERE{
                ?entity a movc:Movie
            }"""
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    n = 0
    for e in res['results']['bindings']:
        n = int(e['Movies']['value'])
    n += 1
    movie_id = "movie" + str(n)

    # Get genres ids
    query = """PREFIX movc: <http://movies.ws/en/class/>
                PREFIX pred: <http://movies.ws/pred/>
                select ?genre ?name where { 
                ?genre a movc:Genre .
                ?genre pred:name ?name
            }"""
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    genre_ids = []
    genre_names = []
    for e in res['results']['bindings']:
        genre_ids.append(e['genre']['value'])
        genre_names.append(e['name']['value'])
    movie_genre_ids = []
    for i in range(len(genre_names)):
        if genre_names[i] in genres:
            movie_genre_ids.append(genre_ids[i])

    # Get country ids
    query = """PREFIX movc: <http://movies.ws/en/class/>
                    PREFIX pred: <http://movies.ws/pred/>
                    select ?country ?name where {
                    ?country a movc:Country .
                    ?country pred:name ?name.
                }"""
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    country_ids = []
    country_names = []
    for e in res['results']['bindings']:
        country_ids.append(e['country']['value'])
        country_names.append(e['name']['value'])
    movie_country_ids = []
    for i in range(len(country_names)):
        if country_names[i] in countries:
            movie_country_ids.append(country_ids[i])

    # Get language ids
    query = """PREFIX movc: <http://movies.ws/en/class/>
                PREFIX pred: <http://movies.ws/pred/>
                select ?language ?name where {
                    ?language a movc:Language .
                    ?language pred:name ?name .
                }"""
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    language_ids = []
    language_names = []
    for e in res['results']['bindings']:
        language_ids.append(e['language']['value'])
        language_names.append(e['name']['value'])
    movie_language_ids = []
    for i in range(len(language_names)):
        if language_names[i] in languages:
            movie_language_ids.append(language_ids[i])

    # Check if director exists and if not create it
    query = """PREFIX movc: <http://movies.ws/en/class/>
            PREFIX pred: <http://movies.ws/pred/>
            select ?director where {{
                ?director a movc:Director .
                ?director pred:name "{}".
            }}""".format(director)
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    director_id = ""
    for e in res['results']['bindings']:
        director_id = e['director']['value']

    if director_id == "":
        director_id = "http://movies.ws/en/director/" + director.lower().replace(" ", "_").replace("'", "_").replace(
            ".", "_")
        query = """
            PREFIX pred: <http://movies.ws/pred/>
            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
            PREFIX movc: <http://movies.ws/en/class/>
            PREFIX dir: <http://movies.ws/en/director/>
            insert data {{
                <{dir_id}> a movc:Director .
                <{dir_id}> pred:name "{dir_name}"^^xsd:string .
            }}""".format(dir_id=director_id, dir_name=director)
        payload_query = {"update": query}
        res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
        print(query)
        print(res)

    # Getting platforms
    query = """PREFIX movc: <http://movies.ws/en/class/>
            PREFIX pred: <http://movies.ws/pred/>
            select ?platform ?name where { 
                ?platform a movc:Platform .
                ?platform pred:name ?name .
            }"""
    payload_query = {"query": query}
    res = accessor.sparql_select(body=payload_query, repo_name=repo_name)
    res = json.loads(res)
    platform_ids = []
    platform_names = []
    for e in res['results']['bindings']:
        platform_ids.append(e['platform']['value'])
        platform_names.append(e['name']['value'])
    movie_platform_ids = []
    for i in range(len(platform_names)):
        if platform_names[i] in platforms:
            movie_platform_ids.append(platform_ids[i])

    # Create movie
    query = """PREFIX pred: <http://movies.ws/pred/>
    PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
    PREFIX movc: <http://movies.ws/en/class/>
    PREFIX dir: <http://movies.ws/en/director/>
    PREFIX movie: <http://movies.ws/en/movie/>
    PREFIX country: <http://movies.ws/en/country/>
    PREFIX lang: <http://movies.ws/en/language/>
    PREFIX genre: <http://movies.ws/en/genre/>
    PREFIX plat: <http://movies.ws/en/platform/>
    insert data {{
        movie:{} a movc:Movie ;\n""".format(movie_id)
    for g in movie_genre_ids:
        query += "pred:genre <{}>;\n".format(g)
    for p in movie_platform_ids:
        query += "pred:available <{}>;\n".format(p)
    for c in movie_country_ids:
        query += "pred:country <{}>;\n".format(c)
    for lang in movie_language_ids:
        query += "pred:language <{}>;\n".format(lang)
    query += """pred:name "{movie_name}"^^xsd:string ;
                  pred:scored {score} ;
                  pred:directed_by <{dir_id}>;
                  pred:age "{age}";
                  pred:runtime {runtime};
                  pred:year {year} .
                  }}""".format(movie_name=name, score=score, year=year,
                               dir_id=director_id, runtime=runtime, age=age)
    #print(query)
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)





def get_actor_info(actor_id="http://www.wikidata.org/entity/Q38111"):
    print("actor name to query -> " + actor_id)

    actor = {
        "actor_id": actor_id,
        "name": "Óscar",
        "gender": "Male",
        "awards_rcv": ["Oscar1", "Oscar2", "Oscar3"],
        "awards_nominated": ["OscarNominated1", "OscarNominated2", "OscarNominated3"],
        "birth_date": "1980",
        "birth_place": "Aveiro",
        "work_period_start": "2000",
        "education": "Doutoramento",
        "residence": "LaLa Land",
        "occupations": ["Arquiteto de Software", "Professor"],
        "followers": "1M",
        "photo":"https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    }


    return actor


def infer_amazing_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:ranking "Amazing" .
        }
        where {
            ?movie pred:scored ?score .
            filter(?score > 8)
        }
        """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_good_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:ranking "Good" .
        }
        where {
            ?movie pred:scored ?score .
            filter(?score >= 6) . # >8 é amazing; 6 - 7.9 é bom, 4-5 average, resto mau
            filter(?score < 8) .
        }
       """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_avg_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:ranking "Average" .
        }
        where {
            ?movie pred:scored ?score .
            filter(?score >= 4) . # >8 é amazing; 6 - 7.9 é bom, 4-6.9 average, resto mau
            filter(?score < 7) .
        }
       """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_bad_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:ranking "Bad" .
        }
        where {
            ?movie pred:scored ?score .
            filter(?score < 4) . # >8 é amazing; 6 - 7.9 é bom, 4-6.9 average, resto mau
        }
       """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_incompleted_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX movc: <http://movies.ws/en/class/>
        PREFIX pred: <http://movies.ws/pred/>

        insert{
            ?movie pred:incomplete "Incomplete" .
        }
        where { 
            ?movie a movc:Movie .
            FILTER NOT EXISTS {
                ?movie pred:directed_by ?m ;
                       pred:country ?m;
                       pred:genre ?m;
                       pred:year ?m ;
                       pred:scored ?m ;
                       pred:available ?m ;
                       pred:language ?m .
            }
        }
       """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_children_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:age_category "Children" .
        }
        where {
            ?movie pred:age ?age .
            filter(?age = "7+" || ?age = "13+") . # 7+ e 13+ criança, 16+ jovens adolescentes, 18+ adulto, all = all
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_young_adult_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:age_category "Young Adult" .
        }
        where {
            ?movie pred:age ?age .
            filter(?age = "16+") . # 7+ e 13+ criança, 16+ jovens adolescentes, 18+ adulto, all = all
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_adults_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:age_category "Adult" .
        }
        where {
            ?movie pred:age ?age .
            filter(?age = "18+") . # 7+ e 13+ criança, 16+ jovens adolescentes, 18+ adulto, all = all
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_everyone_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:age_category "All" .
        }
        where {
            ?movie pred:age ?age .
            filter(?age = "all") . # 7+ e 13+ criança, 16+ jovens adolescentes, 18+ adulto, all = all
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_long_length_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:length "Long" .
        }
        where {
            ?movie pred:runtime ?rt .
            filter(?rt >= 120) . # >=2 horas long, >=1:30h e <2horas médio, >30min e <1:30h pequeno
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_average_length_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:length "Medium" .
        }
        where {
            ?movie pred:runtime ?rt .
            filter(?rt >= 90) . # >=2 horas long, >=1:30h e <2horas médio, >30min e <1:30h pequeno
            filter(?rt < 120) . 
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_short_length_movies():
    query = """
        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX pred: <http://movies.ws/pred/>
        insert {
            ?movie pred:length "Short" .
        }
        where {
            ?movie pred:runtime ?rt .
            filter(?rt >= 30) . # >=2 horas long, >=1:30h e <2horas médio, >30min e <1:30hora pequeno
            filter(?rt < 90) . 
        }
    """
    payload_query = {"update": query}
    res = accessor.sparql_update(body=payload_query, repo_name=repo_name)
    print(res)


def infer_all():
    infer_amazing_movies()
    infer_good_movies()
    infer_avg_movies()
    infer_bad_movies()
    infer_incompleted_movies()
    infer_children_movies()
    infer_young_adult_movies()
    infer_adults_movies()
    infer_everyone_movies()
    infer_long_length_movies()
    infer_average_length_movies()
    infer_short_length_movies()
